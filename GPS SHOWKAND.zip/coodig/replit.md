# PawLingo - Pet-Friendly Language Learning App

## Overview

PawLingo is a mobile-first web application that helps pet owners learn practical phrases in their target language (primarily Spanish) for visiting pet-friendly places like cafés, parks, restaurants, and pet stores. The app combines location-based discovery with AI-powered language tutoring to create an immersive learning experience.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui design system
- **Styling**: Tailwind CSS with custom design tokens
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Middleware**: Express middleware for logging, JSON parsing, and error handling
- **Development**: Hot module replacement via Vite middleware integration

### Database & Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Provider**: Neon Database (serverless PostgreSQL)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Storage Pattern**: Repository pattern with in-memory fallback for development

## Key Components

### Database Schema
The application uses four main tables:
- **Users**: User authentication and preferences (username, password, location, preferred language)
- **Places**: Pet-friendly locations with coordinates, ratings, and language practice phrases
- **Chat Messages**: Conversation history between users and AI tutor
- **Learning Tips**: Daily language tips and practice phrases

### AI Integration
- **Provider**: OpenAI GPT-4o for conversational language tutoring
- **Features**: Context-aware responses, practice exercises, pronunciation guides
- **Use Cases**: Chat-based language practice, generating learning tips, contextual phrase suggestions

### Mobile-First Design
- **Responsive**: Optimized for mobile devices with max-width constraints
- **Navigation**: Bottom navigation pattern with four main sections
- **UI Theme**: Custom color palette (coral, teal, sunny yellow, slate) with light/dark mode support

## Data Flow

1. **User Authentication**: Users register/login with username/password
2. **Place Discovery**: Frontend fetches places from backend API with filtering by category/search
3. **Language Learning**: AI chat system processes user messages and provides contextual responses
4. **Bookmarking**: Users can save favorite places for later reference
5. **Daily Tips**: System generates and displays daily language learning tips

## External Dependencies

### Production Dependencies
- **UI Components**: Radix UI ecosystem for accessible components
- **Forms**: React Hook Form with Zod validation
- **Database**: Drizzle ORM with Neon Database connector
- **AI**: OpenAI API for language tutoring
- **Utilities**: date-fns, clsx, tailwind-merge

### Development Dependencies
- **Build**: Vite, esbuild for production builds
- **Types**: TypeScript, Node.js types
- **Dev Tools**: Replit-specific plugins for development experience

## Deployment Strategy

### Development Environment
- **Platform**: Replit with Node.js 20, PostgreSQL 16 modules
- **Hot Reload**: Vite dev server with HMR
- **Port Configuration**: Frontend on port 5000, external port 80
- **Database**: Auto-provisioned PostgreSQL instance

### Production Build
- **Frontend**: Vite builds to `dist/public` directory
- **Backend**: esbuild bundles server to `dist/index.js`
- **Deployment**: Replit autoscale deployment target
- **Environment**: Production mode with optimized builds

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string (required)
- `OPENAI_API_KEY`: OpenAI API key for AI features
- `NODE_ENV`: Environment mode (development/production)

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 25, 2025. Initial setup
- June 25, 2025. Complete transformation to GPS Showkand school management system
- June 25, 2025. Added comprehensive admin panel with full CRUD operations, data export, and analytics